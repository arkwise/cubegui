/******************************************************************
 * Cube 1.0                                                       *
 * Copyright (c) 2002-2004 Cube Developers. All Rights Reserved.  *
 *                                                                *
 * Web site: http://cubeos.host.sk/                               *
 * E-mail (current maintainer): lipka@freeuk.com                  *
 ******************************************************************/

/*
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include<CUBE.h>
#include<stdio.h>
#include<stdarg.h>

FILE *debug_log;
FILE *low_debug_log;

l_int debug_message(l_text format, ...) // High level debug
{
va_list argptr;
l_int nc = 0;

   va_start(argptr, format);

   if (debug_log)
   {
      fprintf(debug_log, "Message: ");
      vfprintf(debug_log, format, argptr);
      fprintf(debug_log,"\n");
   }
   fflush(debug_log);
   va_end(argptr);
   return nc;
}

l_int debug_warning(l_text format, ...) // High level debug
{
va_list argptr;
l_int nc = 0;

   va_start(argptr, format);

   if (debug_log)
   {
      fprintf(debug_log, "Warning: ");
      vfprintf(debug_log, format, argptr);
      fprintf(debug_log,"\n");
   }
   fflush(debug_log);
   va_end(argptr);
   return nc;
}

l_int debug_error(l_text format, ...) // High level debug
{
va_list argptr;
l_int nc = 0;

   va_start(argptr, format);

   if (debug_log)
   {
      fprintf(debug_log, "ERROR: ");
      vfprintf(debug_log, format, argptr);
      fprintf(debug_log,"\n");
   }
   fflush(debug_log);
   va_end(argptr);
   return nc;
}

l_int debug_fatal(l_text format, ...) // High level debug
{
va_list argptr;
l_int nc = 0;

   va_start(argptr, format);

   if (debug_log)
   {
      fprintf(debug_log, "FATAL ERROR: ");
      vfprintf(debug_log, format, argptr);
      fprintf(debug_log,"\n");
   }
   fflush(debug_log);
   va_end(argptr);
   fprintf(debug_log, "\n\nA fatal error has occurred. Aborting program execution.\n");
   abort();
}

l_int lowdebug_message(l_text format, ...)   // Low level debug
{
va_list argptr;
l_int nc = 0;

   va_start(argptr, format);

   if (low_debug_log)
   {
      fprintf(low_debug_log, "Message: ");
      vfprintf(low_debug_log, format, argptr);
      fprintf(low_debug_log,"\n");
   }
   fflush(low_debug_log);
   va_end(argptr);
   return nc;
}

l_int lowdebug_warning(l_text format, ...)   // Low level debug
{
va_list argptr;
l_int nc = 0;

   va_start(argptr, format);

   if (low_debug_log)
   {
      fprintf(low_debug_log, "Warning: ");
      vfprintf(low_debug_log, format, argptr);
      fprintf(low_debug_log,"\n");
   }
   fflush(low_debug_log);
   va_end(argptr);
   return nc;
}

l_int lowdebug_error(l_text format, ...)   // Low level debug
{
va_list argptr;
l_int nc = 0;

   va_start(argptr, format);

   if (low_debug_log)
   {
      fprintf(low_debug_log, "ERROR: ");
      vfprintf(low_debug_log, format, argptr);
      fprintf(low_debug_log,"\n");
   }
   fflush(low_debug_log);
   va_end(argptr);
   return nc;
}
