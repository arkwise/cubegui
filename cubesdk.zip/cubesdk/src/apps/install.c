/******************************************************************
 * Cube 1.0                                                       *
 * Copyright (c) 2002-2004 Cube Developers. All Rights Reserved.  *
 *                                                                *
 * Web site: http://cubeos.host.sk/                               *
 * E-mail (current maintainer): lipka@freeuk.com                  *
 ******************************************************************/

/*
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include"cube.h"
#include"app.h"
#include"button.h"
#include"stattext.h"
#include"grfx.h"
#include"dialogs.h"
#include"checkbox.h"
#include <registry.h>
#include <iodlg.h>
#include <conio.h>
#include <process.h>
#include <unistd.h>
#include <dir.h>
#include <dos.h>
#include <sys/stat.h>
#include <stdio.h>
#include <stdlib.h>

static DATAFILE *dat = NULL;

// Declarations ////////////////////////////////////////////////////////////////
p_appwin xwin = NULL;
p_textline textlinepath = NULL;
p_textline textlinepack = NULL;
p_stattext packtext = NULL;
p_stattext pathtext = NULL;
p_button browse = NULL;
p_stattext text = NULL;
p_grfx pix = NULL;
p_button cancel = NULL;
p_button ok = NULL;
BITMAP *ico = NULL;

#define MSG_browse       1450000
#define MSG_cancel       1450001
#define MSG_ok           1450002

/* BAR commands (for UnBARring) */
#define CMD_INFO        0
#define CMD_COMMENT     1
#define CMD_STATUS      2
#define CMD_CREATEFILE  100
#define CMD_CREATEDIR   101
#define CMD_CLOSEDIR    102
#define CMD_FINISH      255

typedef struct t_barhead
{
  unsigned char ID[3];
  unsigned char version;
} t_barhead;

void unbar_file(FILE *f)
{
  t_barhead hd;
  if (!f) return;
  fread(&hd, 1, sizeof(hd), f);
  #define READ_PARAMETER {                                      \
    unsigned short len;                                         \
    fread(&len, 1, 2, f);                                       \
    parameter = (char *) malloc(len+1);                         \
    fread(parameter, 1, len, f);                                \
    parameter[len] = 0;                                         \
  };
  
  while (!feof(f)) {
    unsigned char cmd;
    char *parameter;
    fread(&cmd, 1, 1, f);

    if (cmd == CMD_FINISH) {
      msgbox(MW_INFO, MB_OK, "File extracted successfuly.");
      break;
    };
    switch (cmd) {
      case CMD_INFO: {    // parameter contains a line of information.
        READ_PARAMETER;   // Current BARs says only information about the
        free(parameter);  // program that was used to make them.
      }; break;
      case CMD_COMMENT: { // parameter contains a line of comments. Each line
        READ_PARAMETER;   // can have sub-lines, separated with the character
        free(parameter);  // 0xD (13 - '\r'). Current BARs doesn't use this.
      }; break;
      case CMD_STATUS: {  // parameter contains the text that should be
        READ_PARAMETER;   // displayed in the status line (if any)
        free(parameter);
      }; break;
      case CMD_CREATEFILE: {
        unsigned char attrib;
        unsigned short time, date;
        unsigned long size, toread, read = 0;
        struct ftime stime;
        FILE *ouf;

        READ_PARAMETER;
        fread(&attrib, 1, 1, f);
        fread(&time, 1, 2, f);
        fread(&date, 1, 2, f);
        fread(&size, 1, 4, f);

        stime.ft_tsec  = (time & 0x1F);
        stime.ft_min   = (time >> 5) & 0x3F;
        stime.ft_hour  = (time >> 11) & 0x1F;
        stime.ft_day   = (date & 0x1F);
        stime.ft_month = (date >> 5) & 0x0F;
        stime.ft_year  = ((date >> 9) & 0x7F);

        ouf = fopen(parameter, "wb+");
        while (1) {
          char buff[16384];
          toread = 16384;
          if (read+toread > size) toread = size-read;
          fread(&buff, 1, toread, f);
          fwrite(&buff, 1, toread, ouf);
          read += toread;
          if (read == size) break;
        };
        fclose(ouf);
        ouf = fopen(parameter, "rb");
        setftime(fileno(ouf), &stime);
        fclose(ouf);

        free(parameter);
      }; break;
      case CMD_CREATEDIR: {
        READ_PARAMETER;
        mkdir(parameter, S_IWUSR);
        chdir(parameter);
        free(parameter);
      }; break;
      case CMD_CLOSEDIR: {
        chdir("..");
      }; break;
      default: {
      }; break;
    };
  };
}

void file_unbar (l_text filename, l_text path)
{
 FILE *b;

 chdir(path);
 b = fopen(filename, "rb+");
 

 unbar_file(b);
}

static p_list get_file_items()
{
  p_list p = list_init(malloc(sizeof(t_list)), &free_filehistory_item, 0);

  if (p) {
/*     p_registry_search inf = (p_registry_search) malloc(sizeof(t_registry_search));
     if (reg_find_first("system/filetypes", inf)) do {
       l_text title = get_key(inf->name);
       l_text ext = (l_text) malloc(strlen(inf->key.name)+3);
       strcpy(ext, "*.");
       strcat(ext, inf->key.name);

       p->insert(p, new_filehistory_item(title, ext));

       free(ext);
       free(title);
     } while (reg_find_next(inf));
     free(inf);*/

     p->insert(p, new_filehistory_item("Cube installer packages (*.cip)", "*.cip"));
     p->insert(p, new_filehistory_item("Bad ARchive Files (*.bar)", "*.bar"));
  };

  return p;
}


// Others functions/////////////////////////////////////////////////////////////
void   grfx_draw ( p_view o )
{
   t_rect r = o->get_local_extent(o);
   t_point p;

   BITMAP *out = o->begin_paint(o, &p, r);

   if (out)
   {

      masked_blit(ico, out, 0, 0, p.x, p.y, 320, 240);

   }

   o->end_of_paint(o, r);
};

// Events handler //////////////////////////////////////////////////////////////

void global_tr_event ( p_object o, p_event event ) {

if ( event->type & EV_MESSAGE && event->message == MSG_browse ) {
   l_text file = open_dialog("/", "*.*", get_file_items());
     if (file) {
       if (textlinepack->text) free(textlinepack->text);
          textlinepack->set_text(textlinepack, file);
          free(file);
       };
   clear_event(event);
};
if ( event->type & EV_MESSAGE && event->message == MSG_cancel ) {
  /* things to do when button is cliked */
  clear_event(event); // Never forgot it ! (here)
};
if ( event->type & EV_MESSAGE && event->message == MSG_ok ) {
clear_event(event);
 if (strcmp(textlinepack->text,"") == 0) {
  if(strcmp(textlinepath->text,"") == 0) {
      file_unbar(textlinepack->text, textlinepath->text);
      }
  else {
       file_unbar(textlinepack->text, "");
      };
} else {
       msgbox(MW_ERROR, MB_OK, "Please specify a file to use!");
  };
};
if ( event->type & EV_MESSAGE && event->message == MSG_ABOUT ) {
msgbox(MW_APPABOUT, MB_OK, "CPI - Cube package installer\n(based on H:BaR)\n\nInstall your favourite programs...\n\nCopyright (c) 2000 BadSector\nCopyright (c) 2002 Ryan Currie\nCopyright (c) 2002 Lukas Lipka");
  clear_event(event); // Never forgot it ! (here)
};
};

// GRFX intialization //////////////////////////////////////////////////////////

void xwin_init() {

xwin = appwin_init(_malloc(sizeof(t_appwin)),rect_assign(25,50,460,365),"CPI - CubeOS package installer",0|WF_MINIMIZE|WF_ABOUT|WF_SYSMENU,ap_id,&global_tr_event);
  xwin->icon16 = (BITMAP*)GET_DATA(dat, 0);
  VIEW(xwin)->align |= TX_ALIGN_CENTER;
  OBJECT(desktop)->insert(OBJECT(desktop),OBJECT(xwin));

textlinepath = textline_init(malloc(sizeof(t_textline)),rect_assign(195,210,425,230),1024,0);
  OBJECT(xwin)->insert(OBJECT(xwin),OBJECT(textlinepath));

textlinepack = textline_init(malloc(sizeof(t_textline)),rect_assign(195,110,425,130),1024,0);
  OBJECT(xwin)->insert(OBJECT(xwin),OBJECT(textlinepack));

packtext = stattext_init(malloc(sizeof(t_stattext)),rect_assign(197,93,370,105),TX_ALIGN_LEFT,"Enter the location of the package to install");
  OBJECT(xwin)->insert(OBJECT(xwin),OBJECT(packtext));

pathtext = stattext_init(malloc(sizeof(t_stattext)),rect_assign(197,193,370,205),TX_ALIGN_LEFT,"Enter the dos path for the target");
  OBJECT(xwin)->insert(OBJECT(xwin),OBJECT(pathtext));

browse = button_init(malloc(sizeof(t_button)),rect_assign(345,135,425,155),"Browse",MSG_browse,BF_DEFAULT);
  OBJECT(xwin)->insert(OBJECT(xwin),OBJECT(browse));

text = stattext_init(malloc(sizeof(t_stattext)),rect_assign(195,25,430,50),TX_ALIGN_LEFT, "Welcome to the CubeOS installer. Please fill\nin the following information to install.");
  OBJECT(xwin)->insert(OBJECT(xwin),OBJECT(text));

ico = (BITMAP*)GET_DATA(dat, 1);
pix = grfx_init(malloc(sizeof(t_grfx)),rect_assign(10,40,175,310));
  VIEW(pix)->draw = &grfx_draw;
  OBJECT(xwin)->insert(OBJECT(xwin),OBJECT(pix));

cancel = button_init(malloc(sizeof(t_button)),rect_assign(350,285,430,310),"Cancel",MSG_CLOSE,BF_DEFAULT);
  OBJECT(xwin)->insert(OBJECT(xwin),OBJECT(cancel));

ok = button_init(malloc(sizeof(t_button)),rect_assign(265,285,345,310),"OK",MSG_ok,BF_DEFAULT);
  OBJECT(xwin)->insert(OBJECT(xwin),OBJECT(ok));

}
////////////////////////////////////////////////////////////////////////////////

// App main handler (load, unload ... ) ////////////////////////////////////////
app_begin ( void ) {
  if ( ap_process == AP_INIT ) { // Load ...

  dat = conv_to_skipcolor_data(DLXGetFileData(ap_id), CO_SKIP_RED, CO_SKIP_GREEN, CO_SKIP_BLUE);
  xwin_init();

  };
} app_end;

SetInfoAppName("CPI - Cube Package installer");
SetInfoDesciption("Install your CubeOS apps");
SetInfoCopyright("(c) Copyright 2002 Lukas Lipka && Ryan Currie && Bad Sector. All rights reserved.");
SetInfoManufacturer("Gigasoft / Gigasoft studios");
