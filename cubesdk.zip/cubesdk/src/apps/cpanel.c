/******************************************************************
 * Cube 1.0                                                       *
 * Copyright (c) 2002-2004 Cube Developers. All Rights Reserved.  *
 *                                                                *
 * Web site: http://cubeos.host.sk/                               *
 * E-mail (current maintainer): lipka@freeuk.com                  *
 ******************************************************************/

/*
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

/* Control Panel Loader */

#include <CUBE.h>
#include <cp.h>

#ifndef SetInfoDescription   // Only exists in 2.00.11 and higher
   #define SetInfoDescription(x)  SetInfoDesciption(x)
#endif

app_begin(void)
{
   if (ap_process == AP_INIT)
   {
      load_cp();
      DLXUnload(ap_id);
   }
} app_end;

SetInfoAppName("Control Panel Loader");
SetInfoDescription("Control Panel Loader");
SetInfoCopyright("Copyright (c) Owen Rudge 2002");
SetInfoManufacturer("Owen Rudge");
