/******************************************************************
 * Cube 1.0                                                       *
 * Copyright (c) 2002-2004 Cube Developers. All Rights Reserved.  *
 *                                                                *
 * Web site: http://cubeos.host.sk/                               *
 * E-mail (current maintainer): lipka@freeuk.com                  *
 ******************************************************************/

/*
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

/*           painter.c
   
     a simple painting program for CUBE 1.0

     author: bj�rn hallstr�m (heor@softhome.net)
        www: http://www.student.lu.se/~kem01bha/seal

     copyright (c) 2002, Bj�rn Hallstr�m
*/


/****************************************************************/
/* Painter is free software; you can redistribute it and/or     */
/* modify it under the terms of the GNU General Public License  */
/* as published by the Free Software Foundation; either version */
/* 2, or (at your option) any later version.                    */
/*                                                              */
/* Klondike is distributed in the hope that it will be useful,  */
/* but WITHOUT ANY WARRANTY; without even the implied warranty  */
/* of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See  */
/* the GNU General Public License for more details.             */
/*                                                              */
/* You should have received a copy of the GNU General Public    */
/* License along with Klondike; see the file COPYING.  If not,  */
/* write to the Free Software Foundation, 675 Mass Ave,         */
/* Cambridge, MA 02139, USA.                                    */
/*                                                              */
/****************************************************************/





#include <allegro.h>
#include <CUBE.h>
#include <app.h>
#include <button.h>
#include <grfx.h>
#include <menus.h>
#include <stattext.h>
#include <dialogs.h>

p_appwin   win = NULL;
p_grfx     canvas = NULL;
p_grfx     colors = NULL;
p_grfx     pensize_box = NULL;
p_menuview top_menu;
l_int      current_color;
l_int      current_back_color;
l_int		  draw_color;
l_int      coly, colx, coly_r, colx_r;
l_bool     clear_canvas = true;
l_bool     clicked_once = true;
l_int      old_x, old_y, p_x, p_y;
l_int      pen_size = 4;
l_int      pen_shape = 2;
l_int      number_of_shapes = 4;
l_int      selected_tool = 1;
p_button   b_minus, b_plus, b_prev, b_next;
BITMAP     *out;

#define MSG_NEWIMAGE         100001
#define MSG_SMALLERPENCIL    100002
#define MSG_BIGGERPENCIL     100003
#define MSG_NEXTSHAPE        100004
#define MSG_PREVIOUSSHAPE    100005
#define MSG_CLEARIMAGE       100006
#define MSG_SELTOOL_PENCIL   100007
#define MSG_SELTOOL_LINE     100008


void clear_image (void)
{
	t_rect  re;
   p_x = -1;
   p_y = -1;
   clear_canvas = true;
}
		
void draw (void) 
{
	VIEW (canvas)->draw_me (VIEW (canvas)); 
}

void draw_colors (void) 
{
	VIEW (colors)->draw_me (VIEW (colors)); 
}

void draw_pensize (void) 
{
	VIEW (pensize_box)->draw_me (VIEW (pensize_box)); 
}


void click_in_canvas (l_int x, l_int y, l_bool left)
{
	t_rect r;
	
	r = VIEW (canvas)->bounds;
	if ((x < (r.b.x - r.a.x)) && (x >= 1))
	{
		p_x = x;
	}
	
	if ((y < (r.b.y - r.a.y)) && (y >= 1))
	{
		p_y = y;
	}
   
   if (left)
   {
   	draw_color = current_color;
   }
   else
   {
   	draw_color = current_back_color;
   }
   
	draw ();
}

static void translate_canvas_event (p_object o, p_event event) 
{
   t_point p;
   l_bool  l_but;
   
   RETVIEW (o, event);
   if (event->type & EV_MOUSE)
   {
   	// FREEHAND TOOL
      if (selected_tool == 1)
      {
      	if ( (OBJECT (mouse)->state & MO_SF_MOUSELPRESS) || (OBJECT (mouse)->state & MO_SF_MOUSERPRESS))
      	{
      		l_but = OBJECT (mouse)->state & MO_SF_MOUSELPRESS;
         	p = VIEW (o)->get_local_point (VIEW (o), mouse->where);
         	click_in_canvas (p.x, p.y, l_but);
	       	old_x = p_x;
   	   	old_y = p_y;
      	}
      	if ((OBJECT (mouse)->state & MO_SF_MOUSELUP) || (OBJECT (mouse)->state & MO_SF_MOUSERUP))
      	{
      		old_x = -1;
      		old_y = -1;
      	}
      	
      }

      // THE LINE TOOL
      if (selected_tool == 2)
      {
      	if ( (OBJECT (mouse)->state & MO_SF_MOUSELDOWN) || (OBJECT (mouse)->state & MO_SF_MOUSERDOWN))
      	{
      		l_but = OBJECT (mouse)->state & MO_SF_MOUSELPRESS;
	         p = VIEW (o)->get_local_point (VIEW (o), mouse->where);
   	      click_in_canvas (p.x, p.y, l_but);
      	   if (clicked_once)
         	{
	       		old_x = p_x;
   	   		old_y = p_y;
      			clicked_once = false;
      		}
      		else
	      	{
   	   		clicked_once = true;
      		}
      	}
      }

      
      
      clear_event (event);
   }
}

static void translate_colors_event (p_object o, p_event event) 
{
   l_int   x, y;
   t_point p;
   l_int   xx, yy;
   t_rect  cr;
   l_int   temp_x, temp_y;
	
   RETVIEW (o, event);
   if (event->type & EV_MOUSE)
   {
      if ( (OBJECT (mouse)->state & MO_SF_MOUSELPRESS) || (OBJECT (mouse)->state & MO_SF_MOUSERPRESS))
      {
         p = VIEW (o)->get_local_point (VIEW (o), mouse->where);
         if (p.x < 118)
         {
         	if (OBJECT (mouse)->state & MO_SF_MOUSELPRESS)
         	{
         		colx = p.x;
         		coly = p.y;
         	}
         	if (OBJECT (mouse)->state & MO_SF_MOUSERPRESS)
         	{
         	   colx_r = p.x;
         	   coly_r = p.y;
         	}
         }         
         
         /* If the color switcher is clicked, switch back and foreground colors.*/
         if ((OBJECT (mouse)->state & MO_SF_MOUSELDOWN) && (p.x >= 121) && (p.x <= 124) && (p.y >= 22) && (p.y <= 26))
         {
         	temp_x = colx;
         	temp_y = coly;
         	colx = colx_r;
         	coly = coly_r;
         	colx_r = temp_x;
         	coly_r = temp_y;
         }
      }
      
      VIEW (colors)->draw_me (VIEW (colors)); 
      clear_event (event);
   }
}

l_int new_image_window (l_int *he, l_int *wi)
{
	t_rect     r;
	p_appwin   w;
	p_button   b;
	p_stattext lab;
	p_textline width, height;
	l_bool     ret = false;
	
	
	r = rect_assign (0, 0, 250, 200);
	w = appwin_init (_malloc (sizeof (t_appwin)), r, "New image", NULL, ap_id, NULL);
	
   if (w) 
   {
   	VIEW(w)->align |= TX_ALIGN_CENTER;
   }
   OBJECT(desktop)->insert (OBJECT (desktop), OBJECT (w));
   
   lab = stattext_init (_malloc (sizeof (t_stattext)), rect_assign (r.a.x + 10, r.a.y + 30, r.a.x + 75, r.a.y + 45), TX_ALIGN_BOTTOM, "Image width:");
   OBJECT(w)->insert(OBJECT(w), OBJECT(lab));
   width = textline_init (_malloc (sizeof (t_textline)), rect_assign (r.a.x + 79, r.a.y + 30, r.a.x + 110, r.a.y + 50), IO_DIR_LIMIT, 0);
   OBJECT(w)->insert (OBJECT (w), OBJECT (width));
   lab = stattext_init (_malloc (sizeof (t_stattext)), rect_assign (r.a.x + 120, r.a.y + 30, r.a.x + 175, r.a.y + 45), TX_ALIGN_BOTTOM, "pixels");
   OBJECT(w)->insert(OBJECT(w), OBJECT(lab));
   
   lab = stattext_init (_malloc (sizeof (t_stattext)), rect_assign (r.a.x + 10, r.a.y + 60, r.a.x + 75, r.a.y + 75), TX_ALIGN_BOTTOM, "Image height:");
   OBJECT(w)->insert(OBJECT(w), OBJECT(lab));
   height = textline_init (_malloc (sizeof (t_textline)), rect_assign (r.a.x + 79, r.a.y + 60, r.a.x + 110, r.a.y + 80), IO_DIR_LIMIT, 0);
   OBJECT(w)->insert (OBJECT (w), OBJECT (height));
   lab = stattext_init (_malloc (sizeof (t_stattext)), rect_assign (r.a.x + 120, r.a.y + 60, r.a.x + 175, r.a.y + 75), TX_ALIGN_BOTTOM, "pixels");
   OBJECT(w)->insert(OBJECT(w), OBJECT(lab));
   
  
   b = button_init (_malloc (sizeof (t_button)), rect_assign(r.a.x + 30, r.b.y - 40, r.a.x + 100, r.b.y - 20), TXT_OK, MSG_OK, BF_DEFAULT);
   OBJECT(w)->insert (OBJECT (w), OBJECT (b));
	b = button_init (_malloc (sizeof (t_button)), rect_assign(r.a.x + 120, r.b.y - 40, r.a.x + 190, r.b.y - 20), TXT_CANCEL, MSG_CLOSE, BF_DEFAULT);
   OBJECT(w)->insert (OBJECT (w), OBJECT (b));
   
   if (desktop->execute_view (desktop, VIEW (w)) == MSG_OK)
   {
      ret = true;
      (*he) = atoi (width->text);
      (*wi) = atoi (height->text);
   }
  
   dispose (OBJECT (w));
   return ret;
}

static void translate_event ( p_object o, p_event event) 
{
	l_int  h = NULL;
	l_int  w = NULL;
	
	if (event->type == EV_MESSAGE) 
	{
		switch (event->message) 
		{
         case MSG_ABOUT:
         {
            msgbox(MW_APPABOUT, MB_OK, "Painter 1.02");
            clear_event (event);
         }
         break;
        
         case MSG_HELP: 
         {
            open_help ("./help/painter.hlp");
            clear_event (event);
         }
         break;
			
			case MSG_CLEARIMAGE: 
         {
         	clear_image ();
         	draw ();
         	clear_event (event);
         }  			
         break;

         case MSG_NEWIMAGE: 
         {
  				if (new_image_window (&h, &w))
  				{
					VIEW (canvas)->brush.color = COLOR (CO_BLACK);
            	VIEW (canvas)->grow_view (VIEW (canvas), rect_assign (55, 47, 56 + h, 48 + w));
  					clear_image ();
            	draw ();
            }
            clear_event (event);
         }
         break;
         
         case MSG_SMALLERPENCIL:
         {
         	if (pen_size > 0)
         	{
         		pen_size--;
         		draw_pensize ();
         	}
         	if (pen_size == 0)
         	{
         		VIEW (b_minus)->hide (VIEW (b_minus));
          	}	
         	clear_event (event);
         }
         break;

			case MSG_BIGGERPENCIL:
         {
         	if (pen_size == 0)
         	{
         		VIEW (b_minus)->show (VIEW (b_minus));
         	}
         	pen_size++;
         	
         	draw_pensize ();
         	clear_event (event);
         }
         break;
         
         case MSG_PREVIOUSSHAPE:
         {
         	if (pen_shape == number_of_shapes)
         	{
         		VIEW (b_next)->show (VIEW (b_next));
         	}
         	if (pen_shape > 1)
         	{
         		pen_shape--;
         		draw_pensize ();
         	}
         	if (pen_shape == 1)
         	{
         		VIEW (b_prev)->hide (VIEW (b_prev));
          	}	
         	clear_event (event);
         }
         break;

			case MSG_NEXTSHAPE:
         {
         	if (pen_shape == 1)
         	{
         		VIEW (b_prev)->show (VIEW (b_prev));
         	}
         	if (pen_shape < number_of_shapes) 
         	{
         		pen_shape++;
         		draw_pensize ();
         	}
         	if (pen_shape == number_of_shapes)
         	{
         		VIEW (b_next)->hide (VIEW (b_next));
          	}	
         	clear_event (event);
         }
         break;
         
         case MSG_SELTOOL_PENCIL:
         {
         	selected_tool = 1;
         	old_x = -1;
         	old_y = -1;
         	clear_event (event);
         }
         break;
         
         case MSG_SELTOOL_LINE:
         {
         	selected_tool = 2;
         	clear_event (event);
         }
         break;
      }
   }  
}

void canvas_set_mouse_cursor (p_view o)
{
      mouse_set_sys_cursor (CUR_PENCIL);
}

void colors_set_mouse_cursor (p_view o)
{
      mouse_set_sys_cursor (CUR_PENCIL);
}


static p_menu create_menu (void) 
{
   p_menu menu;
   menu = new_menu(
                 new_sub_menu("File", new_menu(
                    new_menu_item("New image", "", 0, MSG_NEWIMAGE, NULL,
                    new_menu_line(
                    new_menu_item(TXT_EXIT, "ALT+F4", 0, MSG_CLOSE, NULL,
                    NULL)))),
                 new_sub_menu(TXT_EDIT, new_menu(
                    new_menu_item("Clear image", "", 0, MSG_CLEARIMAGE, NULL, NULL)),
                    
                 new_sub_menu(TXT_HELP, new_menu(
                    new_menu_item(TXT_HELP, "", 0, MSG_HELP, NULL,
                    new_menu_line(
                    new_menu_item(TXT_ABOUT, "", 0, MSG_ABOUT, NULL,
                    NULL)))),
                 NULL)))
              );
   return menu;
}

void putpixel_cust (BITMAP *bmp, int x, int y, int color)
{
	if (pen_shape == 1)
	{
		rectfill (bmp, x - pen_size / 2, y - pen_size / 2, x+pen_size - pen_size / 2, y+pen_size - pen_size / 2, color);
	}
	if (pen_shape == 2)
	{
		circlefill (bmp, x, y, pen_size, color);
	}
	if (pen_shape == 3)
	{
		line (bmp, x - pen_size/2, y - pen_size/2, x + pen_size - pen_size/2, y + pen_size - pen_size/2, color);
		line (bmp, x - pen_size/2 - 1, y - pen_size/2, x + pen_size - pen_size/2 - 1, y + pen_size - pen_size/2, color);
	}
	if (pen_shape == 4)
	{
		line (bmp, x - pen_size/2, y + pen_size - pen_size/2, x + pen_size - pen_size/2, y - pen_size/2, color);
		line (bmp, x - pen_size/2 - 1, y + pen_size - pen_size/2, x + pen_size - pen_size/2 - 1, y - pen_size/2, color);
	}
}	


void draw_canvas (p_view o) 
{
   t_rect  r = o->get_local_extent (o);
   t_point p;
   l_int   xx, yy;
   t_rect  cr;
   
   out = o->begin_paint (o, &p, r);

      
   if ((out) && (clear_canvas))
   {
      rectfill (out, p.x, p.y, p.x + r.b.x, p.y + r.b.y, current_back_color);
      rect (out, p.x, p.y, p.x + r.b.x, p.y + r.b.y, COLOR (CO_BLACK));
      old_x = -1;
      old_y = -1;
      clear_canvas = false;
   }
  
   cr = VIEW (canvas)->bounds;
   if (selected_tool == 1)
   {
   	if ( (old_x == -1) && (old_y == -1))
   	{
   		/* do nothing */
   	}
   	else
   	{
   		do_line (out, p.x + old_x, p.y + old_y, p.x + p_x, p.y + p_y, draw_color, putpixel_cust);
   	}
   }

   if (selected_tool == 2)
   {
   	if (clicked_once)
   	{
   		putpixel_cust (out, p.x + p_x, p.y + p_y, draw_color);
   	}
   	else
   	{
   		do_line (out, p.x + old_x, p.y + old_y, p.x + p_x, p.y + p_y, draw_color, putpixel_cust);
   	}
   }
   		
   		

   o->end_of_paint(o, r);

}



void draw_pensize_line_box (p_view o)
{
   t_rect  r = o->get_local_extent (o);
   t_point p;

   BITMAP *out = o->begin_paint (o, &p, r);
   
   if (out)
   {
   	rectfill (out, p.x, p.y, p.x + r.b.x, p.y + r.b.y, COLOR (CO_WHITE));
   	rect (out, p.x, p.y, p.x + r.b.x, p.y + r.b.y, COLOR (CO_BLACK));

      do_line (out, p.x + r.b.x / 2, 
                    p.y + r.b.y / 2, 
                    p.x + r.b.x / 2, 
                    p.y + r.b.y / 2, 
                    COLOR (CO_BLACK), &putpixel_cust);
	}
	o->end_of_paint(o, r);
}


l_long makecol2 (l_int r, l_int g, l_int b, l_int light)
{
	l_int rr, gg, bb;
	
	rr = r + light;
	gg = g + light;
	bb = b + light;
	
	if (rr > 255)
		rr = 255;
	if (gg > 255)
		gg = 255;
	if (bb > 255)
		bb = 255;

	if (rr < 0)
		rr = 0;
	if (gg < 0)
		gg = 0;
	if (bb < 0)
		bb = 0;
		
	return (makecol (rr, gg, bb));
}
	
// THIS DRAWS THE SPECTRA TO CHOOSE THE COLOR FROM (and some more). PLEASE DON'T TRY TO UNDERSTAND IT, YOUR HEAD WILL
// PROBABLY EXPLODE. IF YOU WANT TO IMPROVE/MAKE CHANGES TO IT PLEASE RE-WRITE IT, CLEANLY ;)
void draw_colors_box (p_view o) 
{
   t_rect  r = o->get_local_extent (o);
   t_point p;
   l_int   xx, yy;
   t_rect  cr;
   
   BITMAP *out = o->begin_paint (o, &p, r);
   
   if (out)
   {
   	
   	for (xx=0; xx<=(17); xx++)
   	{
   		for (yy=0; yy<=(30); yy++)
   		{
   			putpixel (out, p.x + xx, p.y + yy, makecol2 (255, xx * 15, 0, -255 + yy * 17));
   		}
   	}
   	for (xx=18; xx<=(35); xx++)
   	{
   		for (yy=0; yy<=(30); yy++)
   		{
   			putpixel (out, p.x + xx, p.y + yy, makecol2 (255 - (xx-18) * 15, 255, 0, -255 + yy * 17));
   		}
   	}
   	
   	for (xx=36; xx<=(53); xx++)
   	{
   		for (yy=0; yy<=(30); yy++)
   		{
   			putpixel (out, p.x + xx, p.y + yy, makecol2 (0, 255, (xx-36) * 15, -255 + yy * 17));
   		}
   	}
   	
   	for (xx=54; xx<=(71); xx++)
   	{
   		for (yy=0; yy<=(30); yy++)
   		{
   			putpixel (out, p.x + xx, p.y + yy, makecol2 (0, 255 - (xx-54) * 15, 255, -255 + yy * 17));
   		}
   	}

   	for (xx=72; xx<=(89); xx++)
   	{
   		for (yy=0; yy<=(30); yy++)
   		{
   			putpixel (out, p.x + xx, p.y + yy, makecol2 ((xx-72) * 15, 0, 255, -255 + yy * 17));
   		}
   	}

		for (xx=90; xx<=(107); xx++)
   	{
   		for (yy=0; yy<=(30); yy++)
   		{
   			putpixel (out, p.x + xx, p.y + yy, makecol2 (255, 0, 255 - (xx-90) * 15, -255 + yy * 17));
   		}
   	}

		for (xx=108; xx<=(117); xx++)
   	{
   		for (yy=0; yy<=(30); yy++)
   		{
   			putpixel (out, p.x + xx, p.y + yy, makecol2 (yy * 9, yy * 9, yy * 9, 0));
   		}
   	}
   	
   	current_color = getpixel (out, p.x + colx, p.y + coly);
      current_back_color = getpixel (out, p.x + colx_r, p.y + coly_r);
      
      /* Draw those little markers that shows which color is chosen in the colorpicker */
    	rect (out, p.x + colx - 1, p.y + coly - 1, p.x + colx + 1, p.y + coly + 1, makecol (255 - coly*8, 255 - coly*8, 255 - coly*8));
     	rect (out, p.x + colx_r - 1, p.y + coly_r - 1, p.x + colx_r + 1, p.y + coly_r + 1, makecol (255 - coly_r*8, 255 - coly_r*8, 255 - coly_r*8));
      
      rectfill (out, p.x + 118, p.y, p.x + 146, p.y + 30, COLOR (CO_WHITE));
      
      /* Draws the box showing the background color */
      rectfill (out, p.x + 127, p.y + 13, p.x + 143, p.y + 27, current_back_color);
      rect (out, p.x + 126, p.y + 12, p.x + 144, p.y + 28, COLOR (CO_BLACK));

		/* Draws the box showing the foreground color */
      rectfill (out, p.x + 121, p.y + 3, p.x + 138, p.y + 17, current_color);
      rect (out, p.x + 120, p.y + 2, p.x + 139, p.y + 18, COLOR (CO_BLACK));
      
      /* Draws the little color switcher */
      rectfill (out, p.x + 121, p.y + 22, p.x + 124, p.y + 26, COLOR (CO_BLACK));

      rect (out, p.x + 0, p.y + 0, p.x + 146, p.y + 30, COLOR (CO_BLACK));
   }
   o->end_of_paint(o, r);
}



void init_window (void)
{
   t_rect   r, r2;
   p_button b;
   
   mouse_set_sys_cursor (CUR_PENCIL);
   colx_r = 112;
   coly_r = 30;
   current_back_color = makecol (255, 255, 255);
   colx = 112;
   coly = 1;

   
   
   r = rect_assign (0, 0, 400, 293);
   
   win = appwin_init (_malloc (sizeof (t_appwin)), r, "Painter 0.0.2", WF_MINIMIZE, ap_id, &translate_event);
   
   if (win) 
   {
      VIEW (win)->drag_mode |= DM_DRAGGROW;
      VIEW(win)->align |= TX_ALIGN_CENTER;
   }
   
   win->icon16 = load_image ("/system/bmp/simp.ico,16");
   OBJECT (desktop)->insert(OBJECT (desktop), OBJECT (win));

	r2 = VIEW (win)->size_limits (VIEW (win));
	    
   if (win)
   {
      r = rect_assign (r2.a.x, r2.a.y + 1, r2.a.x, r2.a.y + 20);
      top_menu = hormenu_init (_malloc (sizeof (t_menuview)), r, create_menu ());
      OBJECT (win)->insert (OBJECT (win), OBJECT (top_menu));
   }

   if (win)
   {
   	/* TOOL BUTTONS */
   	r = rect_assign (6, 49, 26, 69);
		b = button_init(_malloc(sizeof(t_button)), r, "~", MSG_SELTOOL_PENCIL, BF_DEFAULT);
		OBJECT (win)->insert (OBJECT (win), OBJECT (b));
		
		r = rect_assign (30, 49, 50, 69);
		b = button_init(_malloc(sizeof(t_button)), r, "/", MSG_SELTOOL_LINE, BF_DEFAULT);
		OBJECT (win)->insert (OBJECT (win), OBJECT (b));

   	/*r = rect_assign (6, 73, 26, 93);
		b = button_init(_malloc(sizeof(t_button)), r, "", MSG_SELTOOL_PENCIL, BF_DEFAULT);
		OBJECT (win)->insert (OBJECT (win), OBJECT (b));
		
		r = rect_assign (30, 73, 50, 93);
		b = button_init(_malloc(sizeof(t_button)), r, "", MSG_SELTOOL_PENCIL, BF_DEFAULT);
		OBJECT (win)->insert (OBJECT (win), OBJECT (b));

   	r = rect_assign (6, 97, 26, 117);
		b = button_init(_malloc(sizeof(t_button)), r, "", MSG_SELTOOL_PENCIL, BF_DEFAULT);
		OBJECT (win)->insert (OBJECT (win), OBJECT (b));
		
		r = rect_assign (30, 97, 50, 117);
		b = button_init(_malloc(sizeof(t_button)), r, "", MSG_SELTOOL_PENCIL, BF_DEFAULT);
		OBJECT (win)->insert (OBJECT (win), OBJECT (b));*/

      
      /* PENSIZE CHANGER */
      r = rect_assign (7, r2.b.y - 80, 20, r2.b.y - 66);
		b_plus = button_init(_malloc(sizeof(t_button)), r, "+", MSG_BIGGERPENCIL, BF_DEFAULT);
		OBJECT (win)->insert (OBJECT (win), OBJECT (b_plus));

	   r = rect_assign (7, r2.b.y - 63, 20, r2.b.y - 49);
		b_minus = button_init(_malloc(sizeof(t_button)), r, "-", MSG_SMALLERPENCIL, BF_DEFAULT);
		OBJECT (win)->insert (OBJECT (win), OBJECT (b_minus));
		
		r = rect_assign (23, r2.b.y - 80, 51, r2.b.y - 48);
      pensize_box = grfx_init (_malloc (sizeof (t_grfx)), r);
		VIEW (pensize_box)->draw = &draw_pensize_line_box;
		OBJECT (win)->insert (OBJECT (win), OBJECT (pensize_box));

      r = rect_assign (23, r2.b.y - 46, 36, r2.b.y - 32);
		b_prev = button_init(_malloc(sizeof(t_button)), r, "<", MSG_PREVIOUSSHAPE, BF_DEFAULT);
		OBJECT (win)->insert (OBJECT (win), OBJECT (b_prev));

	   r = rect_assign (38, r2.b.y - 46, 51, r2.b.y - 32);
		b_next = button_init(_malloc(sizeof(t_button)), r, ">", MSG_NEXTSHAPE, BF_DEFAULT);
		OBJECT (win)->insert (OBJECT (win), OBJECT (b_next));
	}

   if (win)
   {
      r = rect_assign (r2.a.x + 55, r2.a.y + 27, r2.b.x - 5, r2.b.y - 48);
      canvas = grfx_init (_malloc (sizeof (t_grfx)), r);
      clear_image ();
      VIEW (canvas)->draw = &draw_canvas;
      OBJECT (canvas)->translate_event = &translate_canvas_event;
      VIEW (canvas)->set_mouse_cursor = &canvas_set_mouse_cursor;
      OBJECT (win)->insert (OBJECT (win), OBJECT (canvas));
      
   }
   
   if (win)
   {
      r = rect_assign (r2.a.x + 55, r2.b.y - 43, r2.a.x + 284, r2.b.y - 13);
      colors = grfx_init (_malloc (sizeof (t_grfx)), r);
      VIEW (colors)->draw = &draw_colors_box;
      OBJECT (colors)->translate_event = &translate_colors_event;
      VIEW (colors)->set_mouse_cursor = &colors_set_mouse_cursor;
      OBJECT (win)->insert (OBJECT (win), OBJECT (colors));
   }
}

app_begin ( void ) 
{
   if ( ap_process == AP_INIT ) /* When ap start */
   {
      AP_SETNUMOFCALLS (1); /* Set MAX of Calls */
      init_window (); /* Run the init void */
   }

  if (ap_process == AP_FREE) 
  {
  }
  
  if (ap_process == AP_DONE) /* When ap done */
  {
  }
} app_end;
