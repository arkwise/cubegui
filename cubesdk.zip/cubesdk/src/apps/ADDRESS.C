/******************************************************************
 * Cube 1.0                                                       *
 * Copyright (c) 2002-2004 Cube Developers. All Rights Reserved.  *
 *                                                                *
 * Web site: http://cubeos.host.sk/                               *
 * E-mail (current maintainer): lipka@freeuk.com                  *
 ******************************************************************/

/*
   This program is distributed under the terms of of the Gigasoft license.
   For more info look on http://www.gigasoft.host.sk

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

*/

/**********************/
/* Address book v 1.1 */
/**********************/
/*
    This file is part of CUBE.

    (c) Copyright 2002-2003 Gigasoft / Gigasoft studios. All rights reserved.
    Gigasoft website: http://gigasoft.host.sk
    Programmed by: Lukas Lipka (lipka@freeuk.com)
    All rights reserved.

*/

#include "allegro.h"
#include "CUBE.h"
#include "app.h" 
#include "dialogs.h" 
#include "button.h"
#include "helpsys.h"
#include"editor.h"
#include"menus.h"

#define fsize(f) filelength(fileno(f))

#define MSG_PREV 10001
#define MSG_NEXT 10002
#define MSG_SAVE 10003
#define MSG_NEW 10004

////////////////////////////////////////////////////////////////////////////////
SetInfoAppName("Address book v1.1");
SetInfoDescription("Address book");
SetInfoCopyright("Copyright (c) 2002-2003 Lukas Lipka. All rights reserved");
SetInfoManufacturer("Gigasoft / Gigasoft studios");
////////////////////////////////////////////////////////////////////////////////

static DATAFILE *dat = NULL;

typedef struct t_record {
  char name[101];   /* 101=100 maximum characters plus \0 for end-of-string mark */
  char adress[101]; /* 101=100 maximum characters plus \0 for end-of-string mark */
  char city [31];   /* 31=30 maximum characters plus \0 for end-of-string mark */
  char state[31];   /* 31=30 maximum characters plus \0 for end-of-string mark */
  char zipcode[10]; /* 31=30 maximum characters plus \0 for end-of-string mark */
  char phone[53];   /* 53=52  maximum characters plus \0 for end-of-string mark*/
  char email[51];   /* 51=50 maximum characters plus \0 for end-of-string mark */
  char website[61]; /* 61=60 maximum characters plus \0 for end-of-string mark */
  char notes[1001]; /* 1001=1000 maximum characters plus \0 for end-of-string mark */
  char company[61]; /* 61=60 maximum characters plus \0 for end-of-string mark */
} t_record;

p_appwin win;
p_button btPrev, btNext, btSave, btNew;
p_textline tlName, tlAdress, tlCity, tlState, tlZipcode, tlPhone, tlEmail, tlWebsite, tlCompany;
p_editor edinotes= NULL;

l_int idx, cnt; /* record index and count of records in file */

/* This function returns the amount of records in file filename */
l_int get_record_count(const l_text filename)
{
  FILE *f = fopen(filename, "rb"); /* Binary file */
  l_int size = 0;
  if (!f) {    /* if file doesn't exists, create one new with one record */
    t_record r;
    f = fopen(filename, "wb");
    strcpy(r.name, "");
    strcpy(r.adress, "");
    strcpy(r.city, "");
    strcpy(r.state, "");
    strcpy(r.zipcode, "");
    strcpy(r.phone, "");
    strcpy(r.email, "");
    strcpy(r.website, "");
    strcpy(r.notes, "");
    strcpy(r.company, "");
    fwrite(&r, sizeof(t_record), 1, f);
    fclose(f);
    f = fopen(filename, "rb");
  };
  size = fsize(f) / sizeof(t_record);
  fclose(f);

  return size;
};

/* This function saves current record to file filename */
void save_record(const l_text filename)
{
  FILE *f = fopen(filename, "rb+");
  t_record r;

  fseek(f, idx*sizeof(t_record), SEEK_SET);
  strcpy(r.name, tlName->text);
  strcpy(r.adress, tlAdress->text);
  strcpy(r.city, tlCity->text);
  strcpy(r.state, tlState->text);
  strcpy(r.zipcode, tlZipcode->text);
  strcpy(r.phone, tlPhone->text);
  strcpy(r.email, tlEmail->text);
  strcpy(r.website, tlWebsite->text);
  strcpy(r.notes, edinotes->text);
  strcpy(r.company, tlCompany->text);
  fwrite(&r, sizeof(t_record), 1, f);
  fclose(f);
};

/* This function loads a record from the file */
void load_record(const l_text filename, l_int rec)
{
  FILE *f = fopen(filename, "rb");
  t_record r;
  fseek(f, rec*sizeof(t_record), SEEK_SET); /* move to record's position */
  fread(&r, sizeof(t_record), 1, f);
  fclose(f);
  /* change text in Name and Phone fields */
  tlName->set_text(tlName, r.name);
  tlAdress->set_text(tlAdress, r.adress);
  tlCity->set_text(tlCity, r.city);
  tlState->set_text(tlState, r.state);
  tlZipcode->set_text(tlZipcode, r.zipcode);
  tlPhone->set_text(tlPhone, r.phone);
  tlEmail->set_text(tlEmail, r.email);
  tlWebsite->set_text(tlWebsite, r.website);
  edinotes->set_text(edinotes, r.notes);
  tlCompany->set_text(tlCompany, r.company);
  idx = rec;
};

static void translate_event(p_object o, p_event event)
{
  if (event->type == EV_MESSAGE)
  {
    switch (event->message)
    {
      case MSG_PREV: {
        if (idx > 0) load_record("contact.ccl", idx-1);
        clear_event(event);
      } break;
      case MSG_NEXT: {
        if (idx < cnt-1) load_record("contact.ccl", idx+1);
        clear_event(event);
      } break;
      case MSG_SAVE: {
         save_record("contact.ccl");
        clear_event(event);
      } break;
      case MSG_NEW: {
        idx = cnt;
        tlName->set_text(tlName, "");
        tlAdress->set_text(tlAdress, "");
        tlCity->set_text(tlCity, "");
        tlState->set_text(tlState, "");
        tlZipcode->set_text(tlZipcode, "");
        tlPhone->set_text(tlPhone, "");
        tlEmail->set_text(tlEmail, "");
        tlWebsite->set_text(tlWebsite, "");
        edinotes->set_text(edinotes, "");
        tlCompany->set_text(tlCompany, "");
        save_record("contact.ccl");
        cnt++;
        clear_event(event);
      } break;
      case MSG_ABOUT: {
        msgbox(MW_INFO, MB_OK, "Address Book 1.1\n\n(c) Copyright 2002-2003 Gigasoft / Gigasoft studios\nCreated by Lukas Lipka (i_man@inmail.sk)\n\nAll rights reserved");
        clear_event(event);
      }; break;
      case MSG_HELP: {  /* MSG_HELP is defined in CUBE.H */
        open_help("contact.hlp");
        clear_event(event);
      }; break;
    };
  }
}

///
static p_menu app_menu(void) {
   p_menu menu;
   menu = new_menu(
                 new_sub_menu("File", new_menu(
                    new_menu_item(INI_TEXT("Add contact"), "", 0, MSG_NEW, NULL,
                    new_menu_item(INI_TEXT("Save"), "", 0, MSG_SAVE, NULL,
                    new_menu_line(
                    new_menu_item(TXT_EXIT, "ALT+F4", 0, MSG_CLOSE, NULL,
                    NULL))))),
                 new_sub_menu(TXT_HELP, new_menu(
                    new_menu_item(TXT_HELP, "", 0, MSG_HELP, NULL,
                    new_menu_line(
                    new_menu_item(TXT_ABOUT, "", 0, MSG_ABOUT, NULL,
                    NULL)))),
                 NULL))
              );
   return menu;
}
///
void testapp_init() 
{ 
  t_rect r = rect_assign(300, 300, 500, 500);
  p_stattext st1;

  /* Let's create main window */                         //0 ,0,500,215
  win = appwin_init(malloc(sizeof(t_appwin)), rect_assign(0, 0, 500, 250), "Address book", WF_MINIMIZE, ap_id, &translate_event);
  VIEW(win)->align |= TX_ALIGN_CENTER;
  win->icon16 = (BITMAP*)GET_DATA(dat, 0);
  //win->icon16 = load_image("bmp/contact.bmp");
  OBJECT(desktop)->insert(OBJECT(desktop), OBJECT(win));

if ( win ) {

	p_menuview Menu;
    r = VIEW(win)->size_limits(VIEW(win));
    r = rect_assign(r.a.x, r.a.y + 1, r.a.x, r.a.y + 20);
    Menu = hormenu_init(_malloc(sizeof(t_menuview)), r, app_menu());

    OBJECT(win)->insert(OBJECT(win), OBJECT(Menu));
            }
  /* And insert the controls */
  /* button Initialization */
/*btPrev = button_init(malloc(sizeof(t_button)),rect_assign(10,135,70,155),"<-- Prev",MSG_PREV,BF_DEFAULT);
  OBJECT(win)->insert(OBJECT(win),OBJECT(btPrev));

btNext = button_init(malloc(sizeof(t_button)),rect_assign(10,110,70,130),"Next -->",MSG_NEXT,BF_DEFAULT);
  OBJECT(win)->insert(OBJECT(win),OBJECT(btNext));

btSave = button_init(malloc(sizeof(t_button)),rect_assign(10,85,70,105),"Save",MSG_SAVE,BF_DEFAULT);
  OBJECT(win)->insert(OBJECT(win),OBJECT(btSave));

btNew = button_init(malloc(sizeof(t_button)),rect_assign(10,60,70,80),"New",MSG_NEW,BF_DEFAULT);
  OBJECT(win)->insert(OBJECT(win),OBJECT(btNew));
*/
btPrev = button_init(malloc(sizeof(t_button)),rect_assign(10,125,70,145),"<-- Prev",MSG_PREV,BF_DEFAULT);
  OBJECT(win)->insert(OBJECT(win),OBJECT(btPrev));

btNext = button_init(malloc(sizeof(t_button)),rect_assign(10,100,70,120),"Next -->",MSG_NEXT,BF_DEFAULT);
  OBJECT(win)->insert(OBJECT(win),OBJECT(btNext));

btSave = button_init(malloc(sizeof(t_button)),rect_assign(10,75,70,95),"Save",MSG_SAVE,BF_DEFAULT);
  OBJECT(win)->insert(OBJECT(win),OBJECT(btSave));

btNew = button_init(malloc(sizeof(t_button)),rect_assign(10,50,70,70),"New",MSG_NEW,BF_DEFAULT);
  OBJECT(win)->insert(OBJECT(win),OBJECT(btNew));

  /* Stattext initialization */

  r = rect_assign(80, 50, 125, 65);
  st1 = stattext_init(malloc(sizeof(t_stattext)), r, TX_ALIGN_LEFT, "Name:");
  OBJECT(win)->insert(OBJECT(win), OBJECT(st1));

  r = rect_assign(80, 70, 125, 85);
  st1 = stattext_init(malloc(sizeof(t_stattext)), r, TX_ALIGN_LEFT, "Address:");
  OBJECT(win)->insert(OBJECT(win), OBJECT(st1));

  r = rect_assign(80, 90, 125, 105);
  st1 = stattext_init(malloc(sizeof(t_stattext)), r, TX_ALIGN_LEFT, "City:");
  OBJECT(win)->insert(OBJECT(win), OBJECT(st1));

  r = rect_assign(80, 110, 125, 125);
  st1 = stattext_init(malloc(sizeof(t_stattext)), r, TX_ALIGN_LEFT, "State:");
  OBJECT(win)->insert(OBJECT(win), OBJECT(st1));

  r = rect_assign(80, 130, 125, 145);
  st1 = stattext_init(malloc(sizeof(t_stattext)), r, TX_ALIGN_LEFT, "Zip Code:");
  OBJECT(win)->insert(OBJECT(win), OBJECT(st1));

  r = rect_assign(80, 150, 125, 165);
  st1 = stattext_init(malloc(sizeof(t_stattext)), r, TX_ALIGN_LEFT, "Phone:");
  OBJECT(win)->insert(OBJECT(win), OBJECT(st1));

  r = rect_assign(80, 170, 125, 185);
  st1 = stattext_init(malloc(sizeof(t_stattext)), r, TX_ALIGN_LEFT, "Email:");
  OBJECT(win)->insert(OBJECT(win), OBJECT(st1));

  r = rect_assign(80, 190, 125, 205);
  st1 = stattext_init(malloc(sizeof(t_stattext)), r, TX_ALIGN_LEFT, "Website:");
  OBJECT(win)->insert(OBJECT(win), OBJECT(st1));

  r = rect_assign(80, 210, 125, 225);
  st1 = stattext_init(malloc(sizeof(t_stattext)), r, TX_ALIGN_LEFT, "Company:");
  OBJECT(win)->insert(OBJECT(win), OBJECT(st1));

  r = rect_assign(300, 30, 450, 45);
  st1 = stattext_init(malloc(sizeof(t_stattext)), r, TX_ALIGN_LEFT, "Notes:");
  OBJECT(win)->insert(OBJECT(win), OBJECT(st1));

  /* Text-line initialization */

  r =rect_assign(135, 48, 280, 67);
  tlName = textline_init(malloc(sizeof(t_textline)), r, 40, TF_NONE);
  OBJECT(win)->insert(OBJECT(win), OBJECT(tlName));

  r =rect_assign(135, 68, 280, 87);
  tlAdress = textline_init(malloc(sizeof(t_textline)), r, 100, TF_NONE);
  OBJECT(win)->insert(OBJECT(win), OBJECT(tlAdress));

  r =rect_assign(135, 88, 280, 107);
  tlCity = textline_init(malloc(sizeof(t_textline)), r, 25, TF_NONE);
  OBJECT(win)->insert(OBJECT(win), OBJECT(tlCity));

  r =rect_assign(135, 108, 280, 127);
  tlState = textline_init(malloc(sizeof(t_textline)), r, 25, TF_NONE);
  OBJECT(win)->insert(OBJECT(win), OBJECT(tlState));

  r =rect_assign(135, 128, 280, 147);
  tlZipcode = textline_init(malloc(sizeof(t_textline)), r, 10, TF_NONE);
  OBJECT(win)->insert(OBJECT(win), OBJECT(tlZipcode));

  r =rect_assign(135, 148, 280, 167);
  tlPhone = textline_init(malloc(sizeof(t_textline)), r, 30, TF_NONE);
  OBJECT(win)->insert(OBJECT(win), OBJECT(tlPhone));

  r =rect_assign(135, 168, 280, 187);
  tlEmail = textline_init(malloc(sizeof(t_textline)), r, 50, TF_NONE);
  OBJECT(win)->insert(OBJECT(win), OBJECT(tlEmail));

  r =rect_assign(135, 188, 280, 207);
  tlWebsite = textline_init(malloc(sizeof(t_textline)), r, 60, TF_NONE);
  OBJECT(win)->insert(OBJECT(win), OBJECT(tlWebsite));

  r =rect_assign(135, 208, 280, 227);
  tlCompany = textline_init(malloc(sizeof(t_textline)), r, 60, TF_NONE);
  OBJECT(win)->insert(OBJECT(win), OBJECT(tlCompany));

  //r =rect_assign(70, 188, 210, 207);
  //tlNotes = textline_init(malloc(sizeof(t_textline)), r, 26, TF_NONE);
  //OBJECT(win)->insert(OBJECT(win), OBJECT(tlNotes));
  edinotes = editor_init(malloc(sizeof(t_editor)), rect_assign(300,47,475,210), 0);

   VIEW(edinotes)->align |= TX_ALIGN_BOTTOM+TX_ALIGN_RIGHT;

   OBJECT(win)->insert(OBJECT(win), OBJECT(edinotes));


  /* Initialize non-visual things */

  cnt = get_record_count("contact.ccl");
  idx = 0;
  load_record("contact.ccl", idx);
}

app_begin(void) 
{ 
  if (ap_process == AP_INIT) { 
    dat = conv_to_skipcolor_data(DLXGetFileData(ap_id), CO_SKIP_RED, CO_SKIP_GREEN, CO_SKIP_BLUE);
    testapp_init();
  }; 
} app_end;

