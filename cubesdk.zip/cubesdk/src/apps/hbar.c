/**************************************************************
 * H:BaR UnArchiver                                           *
 *           						      *
 * (c) Ryan Currie                                            *
 * (c) Bad ARchive by Bad Sector                              *
 **************************************************************/

/*
 * 24.06.2002: H:BaR Arguments Support Added (Iamryan2002)
 * 28.06.2002: Added Path Support (Iamryan2002)
 */

#include <cube.h>
#include <app.h>
#include <dialogs.h>
#include <registry.h>
#include <iodlg.h>
#include <conio.h>
#include <process.h>
#include <unistd.h>
#include <dir.h>
#include <dos.h>
#include <sys/stat.h>
#include <stdio.h>
#include <stdlib.h>

#define MSG_RUN 10001
#define MSG_HBAR 10002
#define MSG_BROWSE 10003
#define MSG_PATH 10003

p_textline tl = NULL;
p_textline tp = NULL;

/* BAR commands (for UnBARring) */
#define CMD_INFO        0
#define CMD_COMMENT     1
#define CMD_STATUS      2
#define CMD_CREATEFILE  100
#define CMD_CREATEDIR   101
#define CMD_CLOSEDIR    102
#define CMD_FINISH      255

typedef struct t_barhead
{
  unsigned char ID[3];
  unsigned char version;
} t_barhead;

void unbar_file(FILE *f)
{
  t_barhead hd;
  if (!f) return;
  fread(&hd, 1, sizeof(hd), f);
  #define READ_PARAMETER {                                      \
    unsigned short len;                                         \
    fread(&len, 1, 2, f);                                       \
    parameter = (char *) malloc(len+1);                         \
    fread(parameter, 1, len, f);                                \
    parameter[len] = 0;                                         \
  };
  
  while (!feof(f)) {
    unsigned char cmd;
    char *parameter;
    fread(&cmd, 1, 1, f);

    if (cmd == CMD_FINISH) {
      msgbox(MW_INFO, MB_OK, "File Finished. Thanks for using H:BaR!");
      break;
    };
    switch (cmd) {
      case CMD_INFO: {    // parameter contains a line of information.
        READ_PARAMETER;   // Current BARs says only information about the
        free(parameter);  // program that was used to make them.
      }; break;
      case CMD_COMMENT: { // parameter contains a line of comments. Each line
        READ_PARAMETER;   // can have sub-lines, separated with the character
        free(parameter);  // 0xD (13 - '\r'). Current BARs doesn't use this.
      }; break;
      case CMD_STATUS: {  // parameter contains the text that should be
        READ_PARAMETER;   // displayed in the status line (if any)
        free(parameter);
      }; break;
      case CMD_CREATEFILE: {
        unsigned char attrib;
        unsigned short time, date;
        unsigned long size, toread, read = 0;
        struct ftime stime;
        FILE *ouf;

        READ_PARAMETER;
        fread(&attrib, 1, 1, f);
        fread(&time, 1, 2, f);
        fread(&date, 1, 2, f);
        fread(&size, 1, 4, f);

        stime.ft_tsec  = (time & 0x1F);
        stime.ft_min   = (time >> 5) & 0x3F;
        stime.ft_hour  = (time >> 11) & 0x1F;
        stime.ft_day   = (date & 0x1F);
        stime.ft_month = (date >> 5) & 0x0F;
        stime.ft_year  = ((date >> 9) & 0x7F);

        ouf = fopen(parameter, "wb+");
        while (1) {
          char buff[16384];
          toread = 16384;
          if (read+toread > size) toread = size-read;
          fread(&buff, 1, toread, f);
          fwrite(&buff, 1, toread, ouf);
          read += toread;
          if (read == size) break;
        };
        fclose(ouf);
        ouf = fopen(parameter, "rb");
        setftime(fileno(ouf), &stime);
        fclose(ouf);

        free(parameter);
      }; break;
      case CMD_CREATEDIR: {
        READ_PARAMETER;
        mkdir(parameter, S_IWUSR);
        chdir(parameter);
        free(parameter);
      }; break;
      case CMD_CLOSEDIR: {
        chdir("..");
      }; break;
      default: {
      }; break;
    };
  };
}

void file_unbar (l_text filename, l_text path)
{
 FILE *b;

 chdir(path);
 b = fopen(filename, "rb+");
 

 unbar_file(b);
}

static p_list get_file_items()
{
  p_list p = list_init(malloc(sizeof(t_list)), &free_filehistory_item, 0);

  if (p) {
/*     p_registry_search inf = (p_registry_search) malloc(sizeof(t_registry_search));
     if (reg_find_first("system/filetypes", inf)) do {
       l_text title = get_key(inf->name);
       l_text ext = (l_text) malloc(strlen(inf->key.name)+3);
       strcpy(ext, "*.");
       strcat(ext, inf->key.name);

       p->insert(p, new_filehistory_item(title, ext));

       free(ext);
       free(title);
     } while (reg_find_next(inf));
     free(inf);*/

     p->insert(p, new_filehistory_item("Bad ARchive Files (*.bar)", "*.bar"));
  };

  return p;
}

static void handle_event(p_object o, p_event event)
{
  if (event->type == EV_MESSAGE) {
    switch (event->message) {
      case MSG_RUN: {
        clear_event(event);
        if (tl->text != "") {
          if(tp->text != "") {
           file_unbar(tl->text, tp->text);
          } else {
           file_unbar(tl->text, "");
          };
        } else {
          msgbox(MW_INFO, MB_OK, "Give me a file to use!");
        };
      } break;
      case MSG_HBAR: {
        msgbox(MW_INFO, MB_OK, "H:Bar 0.2\n\n (c) 2002 Ryan Currie\n (c) Bad ARchive 2000,2001 Bad Sector\n\nEnjoy H:BaR!");
      } break;
      case MSG_CANCEL: {
      } break;
      case MSG_BROWSE: {
        l_text file = open_dialog("/", "*.bar", get_file_items());
        if (file) {
          if (tl->text) free(tl->text);
          tl->set_text(tl, file);
          free(file);
        };
        clear_event(event);
      } break;
    };
  };
}

void app_init()
{
  t_rect r = rect_assign(100, 100, 358, 243);
  p_appwin w;
  p_stattext t = NULL;
  p_button b = NULL;


  w = appwin_init(malloc(sizeof(t_appwin)), r, "H:BaR 0.2", 0, ap_id, &handle_event);
  WINDOW(w)->flags &= ~WF_SYSMENU;
  OBJECT(desktop)->insert(OBJECT(desktop), OBJECT(w));

  r = rect_assign(10, 25, 248, 45);
  t = stattext_init(malloc(sizeof(t_stattext)), r, TX_ALIGN_LEFT, "Dos Path:");
  OBJECT(w)->insert(OBJECT(w), OBJECT(t));

  r = rect_assign(10, 46, 248, 65);
  tp = textline_init(malloc(sizeof(t_textline)), r, 1024, 0);
  OBJECT(w)->insert(OBJECT(w), OBJECT(tp));

  r = rect_assign(10, 66, 270, 86);
  t = stattext_init(malloc(sizeof(t_stattext)), r, TX_ALIGN_LEFT, "Filename:");
  OBJECT(w)->insert(OBJECT(w), OBJECT(t));

  r = rect_assign(10, 87, 164, 106);
  tl = textline_init(malloc(sizeof(t_textline)), r, 1024, 0);
  OBJECT(w)->insert(OBJECT(w), OBJECT(tl));

  r = rect_assign(168, 87, 248, 106);
  b = button_init(malloc(sizeof(t_button)), r, "Browse...", MSG_BROWSE, BF_DEFAULT);
  OBJECT(w)->insert(OBJECT(w), OBJECT(b));

  r = rect_assign(10, 108, 80, 133);
  b = button_init(malloc(sizeof(t_button)), r, "Extract", MSG_RUN, BF_NORMAL);
  OBJECT(w)->insert(OBJECT(w), OBJECT(b));

  r = rect_assign(84, 108, 164, 133);
  b = button_init(malloc(sizeof(t_button)), r, "Exit", MSG_CLOSE, BF_NORMAL);
  OBJECT(w)->insert(OBJECT(w), OBJECT(b));

  r = rect_assign(168, 108, 248, 133);
  b = button_init(malloc(sizeof(t_button)), r, "About H:Bar", MSG_HBAR, BF_NORMAL);
  OBJECT(w)->insert(OBJECT(w), OBJECT(b));
}

SetInfoAppName("H:BaR UnArchiver");
SetInfoDesciption("H:BaR UnBar Utility");
SetInfoCopyright("(c) Copyright 2000,2002 BadSector & Ryan Currie. All rights reserved");
SetInfoManufacturer("BadSector & Ryan Currie");

app_begin(void)
{
  if (ap_process == AP_INIT) {
    if (ap_args) {
      l_text file = ap_args;
      file_unbar(file, "");
    } else {
      app_init();
    };
  };
} app_end;


