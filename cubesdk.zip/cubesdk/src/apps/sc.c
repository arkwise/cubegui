/******************************************************************
 * Cube 1.0                                                       *
 * Copyright (c) 2002-2004 Cube Developers. All Rights Reserved.  *
 *                                                                *
 * Web site: http://cubeos.host.sk/                               *
 * E-mail (current maintainer): lipka@freeuk.com                  *
 ******************************************************************/

/*
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include"CUBE.h"
#include"app.h"
#include"button.h"
#include"stattext.h"
#include"treeview.h"
#include"dialogs.h"
#include"iodlg.h"

// Declarations ////////////////////////////////////////////////////////////////

SetInfoAppName("Shortcut manager");
SetInfoDescription("Shortcut manager for CUBE");
SetInfoCopyright("(c) Copyright 2002 Lukas Lipka. All rights reserved.");
SetInfoManufacturer("Gigasoft studios");

// Vars ////////////////////////////////////////////////////////////////////////

// Window ///////////////////////
p_appwin win 		= NULL;

// Button ///////////////////////
p_button b			= NULL;
p_button b16        = NULL;
p_button b32        = NULL;

// label ////////////////////////
p_stattext info     = NULL;
p_stattext s		= NULL;

// textline /////////////////////
p_textline path 	= NULL;
p_textline linkname = NULL;
p_textline apptitle = NULL;
p_textline ico16   = NULL;
p_textline ico32   = NULL;

// Vars /////////////////////////
l_text last 		= NULL;
l_text txt 			= NULL;      
l_text sf 			= NULL;
l_text linkk 		= NULL;
l_text nico16		= NULL;
l_text nico32		= NULL;
l_text nico16e		= NULL;
l_text nico32e		= NULL;
l_text ico16f		= NULL;
l_text ico32f		= NULL;
l_text fiico16      = NULL;

// Other ////////////////////////
p_treeview tree 	= NULL;
l_bool ext          = NULL;

// Events /////////////////////////////////////////////////////////////////////
#define MSG_BROWSE 		100001
#define MSG_ADD 		100002
#define MSG_BROWSE16    100003
#define MSG_BROWSE32    100004

// Other functions/////////////////////////////////////////////////////////////

// Function for browsing for app to shortcut to
static p_list get_file_items ( void ) {

  p_list p = list_init(malloc(sizeof(t_list)), &free_filehistory_item, 0);

  if ( p ) {

     p->insert(p, new_filehistory_item("Cube application (*.mxc)", "*.mxc"));
     p->insert(p, new_filehistory_item("All files (*.*)", "*.*"));

  };


  return p;

};

static p_list get_icon16_items ( void ) {

                                                /* function for free-ing items */
  p_list p = list_init(malloc(sizeof(t_list)), &free_filehistory_item, 0);

  if ( p ) {

     p->insert(p, new_filehistory_item("Icon (*.ico)", "*.ico"));
     p->insert(p, new_filehistory_item("Bitmap (bmp.*)", "*.bmp"));
     p->insert(p, new_filehistory_item("All files (*.*)", "*.*"));

  };


  return p;

};

static p_list get_icon32_items ( void ) {

                                                /* function for free-ing items */
  p_list p = list_init(malloc(sizeof(t_list)), &free_filehistory_item, 0);

  if ( p ) {

     p->insert(p, new_filehistory_item("Icon (*.ico)", "*.ico"));
     p->insert(p, new_filehistory_item("Bitmap (bmp.*)", "*.bmp"));
     p->insert(p, new_filehistory_item("All files (*.*)", "*.*"));

  };


  return p;

};


static p_list type_list ( void ) {
  p_list p = list_init(_malloc(sizeof(t_list)), &free_history_item, 0);
  if ( p ) {  
	p_registry_search inf = (p_registry_search) malloc(sizeof(t_registry_search));
    if ( reg_find_first("users/default/CUBE/images", inf) ) do {
      p->insert(p, new_history_item(inf->name ,NULL,0,NULL));
      
      } while (reg_find_next(inf)); 
  };
  return p;
};
// Events handler //////////////////////////////////////////////////////////////

void global_tr_event ( p_object o, p_event event ) {
	
		if (tree->selected->name!=last)
		{ 
	last=tree->selected->name;
	txt = set_format_text(NULL, "Create in %s", last);
          info->set_text(info, txt );

          };
          
          
if ( event->type == EV_MESSAGE ) 
	{

	switch ( event->message ) 
		{

	           case MSG_BROWSE : 
	           { 
	            sf = open_dialog("/", "*.*", get_file_items());
	            path->set_text(path, sf);
	                 
	                 clear_event(event);
	           }; break;
           
           	case MSG_ADD :
           	 {
	           	 
	            linkk =  set_format_text(NULL, "%s/%s.ln", last,linkname->text);       
			 txt = set_format_text(NULL, "[definition]\nlink=\"%s\"\nicon16=\"&IMG_APP16\"\nicon32=\"&IMG_APP32\"", sf);             

      ///
      setini_tofile(linkk, "definition","link",sf,INI_STRING);
      setini_tofile(linkk, "definition","icon16",nico16,INI_STRING);
      setini_tofile(linkk, "definition","icon32",nico32,INI_STRING);
      setini_tofile(linkk, "definition", "title",apptitle->text ,INI_STRING);
      ///
      msgbox(MW_INFO, MB_OK, "Short Cut created succesfully.");
			  clear_event(event);	
	             }; break;
            case MSG_BROWSE16 :
            {
            nico16 = open_dialog("/", "*.*", get_icon16_items());
            ico16->set_text(ico16, nico16);
            clear_event(event);
            }; break;

            case MSG_BROWSE32 :
            {
            nico32 = open_dialog("/", "*.*", get_icon32_items());
            ico32->set_text(ico32, nico32);
            clear_event(event);
            }; break;


           };
	};
};

// App main handler (load, unload ... ) ////////////////////////////////////////
app_begin ( void ) {
  if ( ap_process == AP_INIT ) { // Load ...

  msgbox(MW_WARNING, MB_OK, "This version is still buggy!\nShould work fine in the next version.");

win = appwin_init(_malloc(sizeof(t_appwin)),rect_assign(50,50,550,435),"Cube Short Cut Manager",0|WF_MINIMIZE|WF_SYSMENU,ap_id,&global_tr_event);
  VIEW(win)->align |= TX_ALIGN_CENTER;
  win->icon16 =IMG_DIR16;
  OBJECT(desktop)->insert(OBJECT(desktop),OBJECT(win));
  
  
tree = treeview_init(malloc(sizeof(t_treeview)),rect_assign(20,35,205,365));
   VIEW(tree)->align |= TX_ALIGN_BOTTOM;
  OBJECT(win)->insert(OBJECT(win),OBJECT(tree));
  
  
   info = stattext_init(_malloc(sizeof(t_stattext)),
                      rect_assign(230, 35, 500, 60),
                      TX_ALIGN_CENTERY,
                      "Create in ");
  OBJECT(win)->insert(OBJECT(win), OBJECT(info));

      path = textline_init( _malloc(sizeof(t_textline)),
                            rect_assign(230, 65, 490, 85),
                            255,
                            0);

      OBJECT(win)->insert(OBJECT(win), OBJECT(path));
  
     b = button_init(_malloc(sizeof(t_button)),
                      rect_assign(400,90, 490, 110),
                      "Browse",
                      MSG_BROWSE,
                      BF_DEFAULT);
  OBJECT(win)->insert(OBJECT(win), OBJECT(b));
  
  
   s = stattext_init(_malloc(sizeof(t_stattext)),
                      rect_assign(230, 118, 500,130),
                      TX_ALIGN_CENTERY,
                      "Shortcut name : (without .ln)");
  OBJECT(win)->insert(OBJECT(win), OBJECT(s));
  

   linkname = textline_init( _malloc(sizeof(t_textline)),
                            rect_assign(230, 135, 490, 155),
                            255,
                            0);
      OBJECT(win)->insert(OBJECT(win), OBJECT(linkname));
  
   s = stattext_init(_malloc(sizeof(t_stattext)),
                      rect_assign(230, 165, 500,175),
                      TX_ALIGN_CENTERY,
                      "Application name :");
  OBJECT(win)->insert(OBJECT(win), OBJECT(s));
  

   apptitle = textline_init( _malloc(sizeof(t_textline)),
                            rect_assign(230, 182, 490, 202),
                            255,
                            0);
      OBJECT(win)->insert(OBJECT(win), OBJECT(apptitle));

   s = stattext_init(_malloc(sizeof(t_stattext)),
                      rect_assign(232, 210, 500,220),
                      TX_ALIGN_CENTERY,
                      "Icon 16 :");
  OBJECT(win)->insert(OBJECT(win), OBJECT(s));
  

  ico16 = textline_init( _malloc(sizeof(t_textline)),
                            rect_assign(230, 225, 490, 245),
                            255,
                            0);
  OBJECT(win)->insert(OBJECT(win), OBJECT(ico16));

  b16 = button_init(_malloc(sizeof(t_button)),
                      rect_assign(400,250, 490, 270),
                      "Browse",
                      MSG_BROWSE16,
                      BF_DEFAULT);
  OBJECT(win)->insert(OBJECT(win), OBJECT(b16));

  s = stattext_init(_malloc(sizeof(t_stattext)),
                      rect_assign(232, 275, 280,285),
                      TX_ALIGN_CENTERY,
                      "Icon 32 :");
  OBJECT(win)->insert(OBJECT(win), OBJECT(s));

   ico32 = textline_init( _malloc(sizeof(t_textline)),
                            rect_assign(230, 290, 490, 310),
                            255,
                            0);
   OBJECT(win)->insert(OBJECT(win), OBJECT(ico32));

  b32 = button_init(_malloc(sizeof(t_button)),
                      rect_assign(400,315, 490, 335),
                      "Browse",
                      MSG_BROWSE32,
                      BF_DEFAULT);
  OBJECT(win)->insert(OBJECT(win), OBJECT(b32));

/*   s = stattext_init(_malloc(sizeof(t_stattext)),
                      rect_assign(230, 200, 260,220),
                      TX_ALIGN_CENTERY,
                      "Ico 16 : ");
  OBJECT(win)->insert(OBJECT(win), OBJECT(s));
      
     s = stattext_init(_malloc(sizeof(t_stattext)),
                      rect_assign(230, 240, 260,260),
                      TX_ALIGN_CENTERY,
                      "Ico 32 : ");
  OBJECT(win)->insert(OBJECT(win), OBJECT(s));
      
    ico16 = history_init(_malloc(sizeof(t_history)),
                            rect_assign(270,200,450,220 ),
                            type_list(),
                            150,
                            HF_REWRITEUNABLE|LF_SELFLIST);
  OBJECT(win)->insert(OBJECT(win), OBJECT(ico16));
  
    ico32 = history_init(_malloc(sizeof(t_history)),
                            rect_assign(270,240,450,260 ),
                            type_list(),
                            150,
                            HF_REWRITEUNABLE|LF_SELFLIST);
  OBJECT(win)->insert(OBJECT(win), OBJECT(ico32));
  */
  b = button_init(_malloc(sizeof(t_button)),
                      rect_assign(240,350, 470, 370),
                      "Create",
                      MSG_ADD,
                      BF_DEFAULT);
  OBJECT(win)->insert(OBJECT(win), OBJECT(b));
                           

  * tree->add(tree,_strdup("root"),_strdup("/"),_strdup("Programs"),IMG_DIR16,true,NULL);
   tree->load_from_dir(tree,_strdup("/"),_strdup("./Programs/"));

  };
} app_end;
