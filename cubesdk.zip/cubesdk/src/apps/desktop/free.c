/******************************************************************
 * Cube 1.0                                                       *
 * Copyright (c) 2002-2004 Cube Developers. All Rights Reserved.  *
 *                                                                *
 * Web site: http://cubeos.host.sk/                               *
 * E-mail (current maintainer): lipka@freeuk.com                  *
 ******************************************************************/

/*
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "free.h"

/*
 *  Function   :    getdiskfree
 *  Topics     :    Returns the number of bytes free of a disk.
 *  Parameters :    in int disk  0 = A:, 1 = B:
 *  Return code:    number of bytes free, -1 if invalid drive
 */

long getdiskfree(int disk)
{
   struct diskfree_t free;

   if(_dos_getdiskfree(disk + 1, &free))
      return -1;

   return (long) free.avail_clusters *
          (long) free.bytes_per_sector *
          (long) free.sectors_per_cluster;
}

long getdisktotal(int disk)
{
   struct diskfree_t total;

   if(_dos_getdiskfree(disk + 1, &total))
      return -1;

   return (long) total.total_clusters *
          (long) total.bytes_per_sector *
          (long) total.sectors_per_cluster;
}

t_idisk getpercentused(int disk)
{
   t_idisk driven;
   driven.free = getdiskfree(disk);
   driven.total = getdisktotal(disk);
   return driven;
}
