/******************************************************************
 * Cube 1.0                                                       *
 * Copyright (c) 2002-2004 Cube Developers. All Rights Reserved.  *
 *                                                                *
 * Web site: http://cubeos.host.sk/                               *
 * E-mail (current maintainer): lipka@freeuk.com                  *
 ******************************************************************/

/*
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/


#ifndef _CUBE_H_
#define _CUBE_H_

#define CUBE_1
#define DEV_VERSION

#define CUBE_VER_MAJOR         1
#define CUBE_VER_MINOR         0
#define CUBE_VER_REVISION      00

#define text_loaded(x) ((x) && *(x))

#include "engine.h"
#include "object.h"
#include "view.h"
#include "keyboard.h"
#include "mouse.h"
#include "registry.h"
#include "fonts.h"
#include "window.h"
#include "txts.h"
#include "bmps.h"
#include "colors.h"
#include "vfile.h"
#include "debug.h"
#include "files.h"
#include "skin.h"

#endif

