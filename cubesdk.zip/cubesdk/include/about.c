/******************************************************************
 * Cube 1.0                                                       *
 * Copyright (c) 2002-2004 Cube Developers. All Rights Reserved.  *
 *                                                                *
 * Web site: http://cubeos.host.sk/                               *
 * E-mail (current maintainer): lipka@freeuk.com                  *
 ******************************************************************/

/*
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

p_appwin win_about = NULL;

p_stattext stattext3 = NULL;

p_icon icon = NULL;

#define MSG_button1 1450001
p_button button1 = NULL;

p_stattext ver = NULL;

// Others functions/////////////////////////////////////////////////////////////

// Events handler //////////////////////////////////////////////////////////////

void global_tr_event ( p_object o, p_event event ) {

if ( event->type & EV_MESSAGE && event->message == MSG_button1 ) {
  /* things to do when button is cliked */
  clear_event(event); // Never forgot it ! (here)
};
};

// App main handler (load, unload ... ) ////////////////////////////////////////
void about_OS ( void ) {

char *OS = "????";
check_cpu();

win_about = appwin_init(_malloc(sizeof(t_appwin)),rect_assign(215,230,500,435),"About CubeOS",0|WF_SYSMENU,NULL,&global_tr_event);
  VIEW(win_about)->align |= TX_ALIGN_CENTER;
  OBJECT(desktop)->insert(OBJECT(desktop),OBJECT(win_about));

stattext3 = stattext_init(malloc(sizeof(t_stattext)),rect_assign(130,40,275,165), TX_ALIGN_LEFT,"Cpu:\n - Vendor: %s\n - Family: %d\n\nOS:\n - Name: %s\n\n\nUpdates from internet:\nhttp://cubeos.host.sk",&cpu_vendor,cpu_family,OS);
  OBJECT(win_about)->insert(OBJECT(win_about),OBJECT(stattext3));

  icon = icon_init(_malloc(sizeof(t_icon)),rect_assign(20,40,105,120),load_image("bmp/abos.bmp"),NULL,NULL);
  VIEW(icon)->drag_mode = 0;
  OBJECT(win_about)->insert(OBJECT(win_about),OBJECT(icon));

button1 = button_init(malloc(sizeof(t_button)),rect_assign(220,175,280,200),"OK",MSG_CLOSE,BF_DEFAULT);
  OBJECT(win_about)->insert(OBJECT(win_about),OBJECT(button1));

ver = stattext_init(malloc(sizeof(t_stattext)),rect_assign(20,135,120,160), TX_ALIGN_CENTER,"CubeOS %s", CUBEApiTxtVersion);
  OBJECT(win_about)->insert(OBJECT(win_about),OBJECT(ver));

};
